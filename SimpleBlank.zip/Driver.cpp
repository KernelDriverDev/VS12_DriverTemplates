#include "common.h"

NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath)
{
	DriverObject->DriverUnload = (PDRIVER_UNLOAD)UnloadDriver;
	KPrint("hello world");
	return STATUS_SUCCESS;
}

NTSTATUS UnloadDriver(PDRIVER_OBJECT DriverObject)
{
	KPrint("unload successfully");
	return STATUS_SUCCESS;
}