#include <ntddk.h>

#define KPrint(x) DbgPrintEx(0, 0, x)

NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath);

NTSTATUS UnloadDriver(PDRIVER_OBJECT DriverObject);
