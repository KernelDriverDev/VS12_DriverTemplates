#include "common.h"

VOID CreateThreadNotifyCallback(HANDLE  ProcessId, HANDLE  ThreadId, BOOLEAN  Create);

typedef struct _NotifyRing3ProcessScanContext{
	ULONG ThreadID;
	ULONG ProcessID;
	ULONG64 ThreadBaseAddr;
}NotifyRing3ProcessScanContext,*PNotifyRing3PvrocessScanContext;