#include "common.h"

VOID LoadImageNotifyCallback(PUNICODE_STRING FullImageName,HANDLE ProcessId,PIMAGE_INFO ImageInfo);

typedef struct _NotifyRing3BlockDllHijackingContext{
	ULONG ProcessID;
	PUNICODE_STRING FullImageName;
}NotifyRing3BlockDllHijackingContext,*PNotifyRing3BlockDllHijackingContext;