#include <ntddk.h>

#define KPrint(x) DbgPrintEx(0, 0, x)

#define _In_


NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath);

NTSTATUS UnloadDriver(PDRIVER_OBJECT DriverObject);

extern "C"{
	UCHAR *PsGetProcessImageFileName(PEPROCESS EProcess);
	NTSTATUS PsLookupProcessByProcessId(HANDLE ProcessId, PEPROCESS *Process);
	PCHAR GetProcessNameByProcessId(HANDLE ProcessId);
}