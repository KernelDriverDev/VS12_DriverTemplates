#include "common.h"
#include "ProcessCallback.h"
#include "ThreadCallback.h"
#include "LoadImageCallback.h"

/*
reference from: https://www.cnblogs.com/LyShark/p/14735438.html
*/

VOID UnDriver(PDRIVER_OBJECT driver)
{
	UNREFERENCED_PARAMETER(driver);
    NTSTATUS status;
    status = PsSetCreateProcessNotifyRoutineEx((PCREATE_PROCESS_NOTIFY_ROUTINE_EX)CreateProcessNotifyCallbackEx, TRUE);
	status = PsRemoveCreateThreadNotifyRoutine((PCREATE_THREAD_NOTIFY_ROUTINE)CreateThreadNotifyCallback);
	status = PsSetLoadImageNotifyRoutine((PLOAD_IMAGE_NOTIFY_ROUTINE)CreateThreadNotifyCallback);
    DbgPrint(("call undriver successfully\n"));
}

NTSTATUS DriverEntry(IN PDRIVER_OBJECT Driver, PUNICODE_STRING RegistryPath)
{
	UNREFERENCED_PARAMETER(RegistryPath);
    NTSTATUS status;
    status = PsSetCreateProcessNotifyRoutineEx((PCREATE_PROCESS_NOTIFY_ROUTINE_EX)CreateProcessNotifyCallbackEx, FALSE);
	status = PsSetCreateThreadNotifyRoutine((PCREATE_THREAD_NOTIFY_ROUTINE)CreateThreadNotifyCallback);
	status = PsSetLoadImageNotifyRoutine((PLOAD_IMAGE_NOTIFY_ROUTINE)LoadImageNotifyCallback);
    Driver->DriverUnload = UnDriver;
    DbgPrint("call driverentry successfully!\n");
    return STATUS_SUCCESS;
}