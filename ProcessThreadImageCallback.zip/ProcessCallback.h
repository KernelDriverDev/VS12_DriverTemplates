#include "common.h"


VOID CreateProcessNotifyCallbackEx(PEPROCESS Process, HANDLE ProcessId, PPS_CREATE_NOTIFY_INFO CreateInfo);

typedef BOOLEAN (*RulesTriggerDetection)(PEPROCESS ParentProcess);
typedef struct _BlockProcessCreateContext{
	PCHAR ProcessName;
	RulesTriggerDetection Callback[3];
}BlockProcessCreateContext,*PBlockProcessCreateContext;


BOOLEAN BlockWebServiceCreateProcess(PEPROCESS ParentProcess);
BOOLEAN BlockSystemProcessCreateProcess(PEPROCESS ParentProcess);
BOOLEAN BlockOfficeProcessCreateProcess(PEPROCESS ParentProcess);