#include "ProcessCallback.h"

const BlockProcessCreateContext BlockProcesses[] = {
	{"cmd.exe",{BlockWebServiceCreateProcess,BlockSystemProcessCreateProcess,BlockOfficeProcessCreateProcess}},
	{"powershell.exe",{BlockWebServiceCreateProcess,BlockSystemProcessCreateProcess,BlockOfficeProcessCreateProcess}},
};

PCHAR OfficeProcess[] = {
	"WINWORD.exe",
	"POWERPNT.exe",
	"OUTLOOK.exe",
	"ONENOTE.exe",
	"EXCEL.exe"
};

VOID CreateProcessNotifyCallbackEx(PEPROCESS Process, HANDLE ProcessId, PPS_CREATE_NOTIFY_INFO CreateInfo)
{
    char ProcName[16] = { 0 };
    if (CreateInfo != NULL)
    {
		strcpy(ProcName, (const char*)PsGetProcessImageFileName(Process));
        DbgPrint("PPID: %ld  --->ParentName: %s --->Name: %s---->Image��%wZ\n", CreateInfo->ParentProcessId,
            GetProcessNameByProcessId(CreateInfo->ParentProcessId),
            PsGetProcessImageFileName(Process),CreateInfo->ImageFileName);

		for (int i = 0; i < ARRAYSIZE(BlockProcesses); i++)
		{
			if (0 == strcmp(ProcName, BlockProcesses[i].ProcessName))
			{
				DbgPrint("detect process: %s\n",ProcName);
				for (int j = 0; j < 3; j++)
				{
					PEPROCESS ParentProcess = NULL;
					if(STATUS_SUCCESS == PsLookupProcessByProcessId(CreateInfo->ParentProcessId,&ParentProcess)){
						if(BlockProcesses[i].Callback[j](ParentProcess)){
							CreateInfo->CreationStatus = STATUS_ACCESS_DENIED;
						}
						if(ParentProcess != NULL){
							ObDereferenceObject(ParentProcess);
						}
					}
				}
			}
		}
    }
    else
    {
        strcpy(ProcName,  (const char*)PsGetProcessImageFileName(Process));
        DbgPrint("[ %s ] Removed\n",ProcName);
    }
}

/*
w3wp.exe
sqlserver.exe
sqlwriter.exe
*/
BOOLEAN BlockWebServiceCreateProcess(PEPROCESS ParentProcess){
	return FALSE;
}

/*
check process intergritys
*/
BOOLEAN BlockSystemProcessCreateProcess(PEPROCESS ParentProcess){
	return FALSE;
}

/*
Office 
WINWORD.exe

*/
BOOLEAN BlockOfficeProcessCreateProcess(PEPROCESS ParentProcess){

	DbgPrint("block office process %s\n",(const char*)PsGetProcessImageFileName(ParentProcess));

	for (int i = 0; i < ARRAYSIZE(OfficeProcess); i++)
	{
		if(0 == strcmp((const char*)PsGetProcessImageFileName(ParentProcess),OfficeProcess[i]))
		{
			DbgPrint("block parent %s create process\n",OfficeProcess[i]);
			return TRUE;
		}
	}

	return FALSE;
}