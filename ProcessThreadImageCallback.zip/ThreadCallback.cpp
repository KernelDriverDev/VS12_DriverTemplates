#include "ThreadCallback.h"

VOID CreateThreadNotifyCallback(HANDLE  ProcessId, HANDLE  ThreadId, BOOLEAN  Create)
{
	PEPROCESS eprocess = NULL;
	if(STATUS_SUCCESS == PsLookupProcessByProcessId(ProcessId, &eprocess)){
		if (Create)
		{
			DbgPrint("TID: %1d --> process name: %s --> pid: %1d \n", ThreadId, PsGetProcessImageFileName(eprocess), PsGetProcessId(eprocess));
		}
	}         
	if(NULL != eprocess)
	{
		ObDereferenceObject(eprocess);
	}
}