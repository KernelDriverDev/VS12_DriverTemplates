#include "LoadImageCallback.h"

VOID LoadImageNotifyCallback(PUNICODE_STRING FullImageName,HANDLE ProcessId,PIMAGE_INFO ImageInfo)
{
	PEPROCESS eprocess = NULL;
	if(STATUS_SUCCESS == PsLookupProcessByProcessId(ProcessId, &eprocess)){
		DbgPrint("process name: %s --> pid: %1d  image: %wZ\n",PsGetProcessImageFileName(eprocess), PsGetProcessId(eprocess),FullImageName);
	}         
	if(NULL != eprocess)
	{
		ObDereferenceObject(eprocess);
	}
}