#pragma once
#include "common.h"

#define IOCTL_TEST CTL_CODE(FILE_DEVICE_UNKNOWN,0x100,METHOD_BUFFERED,FILE_ANY_ACCESS)
typedef struct _TestModel {
	PVOID Args;
} TestModel, * PTestModel;