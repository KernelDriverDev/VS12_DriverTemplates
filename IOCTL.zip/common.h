#pragma once
#include <ntddk.h>
#define H_IOCTL
/*
Description:	IOCTL Driver Template
Date:			2024-5-8
Author:			bopin

todo:   https://github.com/yksten/struct2x   c/c++ struct (de)serialize just like COM  UnMarshal for parameters parsed
*/

/*
must comment DEBUG_TEST  when you release ...
*/
#define DEBUG_TEST

#ifdef DEBUG_TEST
#define KDPrint(x) DbgPrint(x);
#define KPrint(x) DbgPrintEx(0, 0, x);
#else
#define KDPrint(x)
#define KPrint(x)
#endif


#define g_DeviceName		L"\\Device\\ioctl_test"
#define g_SymbolicLinkName	L"\\??\\ioctl_test"
#define g_DriverShortName	L"ioctl_test"
#define PoolTag				'YJBP'
#define MAX_PATH			256


NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath);
