#pragma once
#include "datamodel.h"

#if __cplusplus
extern "C" {
#endif

#pragma warning(disable: 4996)

class ioctl {
public:
    static NTSTATUS DispatchCreate(PDEVICE_OBJECT pDevObj, PIRP pIrp);
    static NTSTATUS DispatchClose(PDEVICE_OBJECT pDevObj, PIRP pIrp);
    static NTSTATUS DispatchIoctl(PDEVICE_OBJECT pDevObj, PIRP pIrp);
    static NTSTATUS CreateDriverObject(PDRIVER_OBJECT pDriver);
    static NTSTATUS DriverUnload(PDRIVER_OBJECT DriverObject);

    static LPWSTR DeviceName;
    static LPWSTR SymbolicLinkName;
    static LPWSTR DriverShortName;
    static void Init(LPWSTR name){}
private:

};
#if __cplusplus
}
#endif