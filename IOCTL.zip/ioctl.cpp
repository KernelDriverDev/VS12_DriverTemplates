#include "ioctl.h"

#if __cplusplus
extern "C" {
#endif

LPWSTR ioctl::DeviceName = g_DeviceName;
LPWSTR ioctl::SymbolicLinkName = g_SymbolicLinkName;
LPWSTR ioctl::DriverShortName = g_DriverShortName;


NTSTATUS ioctl::DriverUnload(PDRIVER_OBJECT DriverObject)
{
    PDEVICE_OBJECT pDev;                                                
    UNICODE_STRING SymLinkName;                                         
    pDev = DriverObject->DeviceObject;
    IoDeleteDevice(pDev);                                               
    RtlInitUnicodeString(&SymLinkName, ioctl::SymbolicLinkName);     
    IoDeleteSymbolicLink(&SymLinkName);  
    KPrint("driver unload...");
	return STATUS_SUCCESS;
}

NTSTATUS ioctl::DispatchCreate(PDEVICE_OBJECT pDevObj, PIRP pIrp)
{
    pIrp->IoStatus.Status = STATUS_SUCCESS;          
    KPrint("Dispatch function IRP_MJ_CREATE invoke \n");
    IoCompleteRequest(pIrp, IO_NO_INCREMENT);        
    return STATUS_SUCCESS;                   
}

NTSTATUS ioctl::DispatchClose(PDEVICE_OBJECT pDevObj, PIRP pIrp)
{
    pIrp->IoStatus.Status = STATUS_SUCCESS;          
    KPrint("Dispatch function IRP_MJ_CLOSE invoke \n");
    IoCompleteRequest(pIrp, IO_NO_INCREMENT);
    return STATUS_SUCCESS;
}

NTSTATUS ioctl::CreateDriverObject(PDRIVER_OBJECT pDriver)
{
    NTSTATUS status;
    PDEVICE_OBJECT pDevObj;
    UNICODE_STRING DeviceName;
    UNICODE_STRING SymLinkName;

    RtlInitUnicodeString(&DeviceName,ioctl::DeviceName);
    status = IoCreateDevice(pDriver,
            0,
            &DeviceName,
            FILE_DEVICE_UNKNOWN,
            0,
            TRUE,
            &pDevObj
        );
    KPrint("IoCreateDevice successfully \n");
    pDevObj->Flags |= DO_BUFFERED_IO;
    RtlInitUnicodeString(&SymLinkName, ioctl::SymbolicLinkName);
    status = IoCreateSymbolicLink(&SymLinkName, &DeviceName);
    KPrint("IoCreateSymbolicLink successfully \n");
    return status;
}

NTSTATUS ioctl::DispatchIoctl(PDEVICE_OBJECT pDevObj, PIRP pIrp)
{
    NTSTATUS status = STATUS_INVALID_DEVICE_REQUEST;
    PIO_STACK_LOCATION pIrpStack;
    ULONG uIoControlCode;
    PVOID pIoBuffer;
    ULONG uInSize;
    ULONG uOutSize;

    KeEnterCriticalRegion();
    pIrpStack = IoGetCurrentIrpStackLocation(pIrp);
    uIoControlCode = pIrpStack->Parameters.DeviceIoControl.IoControlCode;
    pIoBuffer = pIrp->AssociatedIrp.SystemBuffer;
    uInSize = pIrpStack->Parameters.DeviceIoControl.InputBufferLength;
    uOutSize = pIrpStack->Parameters.DeviceIoControl.OutputBufferLength;

    __try
    {
        switch(uIoControlCode){
            case IOCTL_TEST:
            {
                KDPrint("ioctl irp dispatch  IOCTL_TEST\n");
                break;
            }
        }
        if (status == STATUS_SUCCESS)
            pIrp->IoStatus.Information = uOutSize;
        else
            pIrp->IoStatus.Information = 0;
    }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        KDPrint("query interface execute failed\n");
    }
    pIrp->IoStatus.Status = status;
    IofCompleteRequest(pIrp, IO_NO_INCREMENT);
    KeLeaveCriticalRegion();
    return status;
}

#if __cplusplus
}
#endif
