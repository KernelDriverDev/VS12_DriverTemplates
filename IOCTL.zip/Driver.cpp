#include "ioctl.h"

NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath)
{
	ioctl::Init(g_DriverShortName);
	ioctl::CreateDriverObject(DriverObject);

	DriverObject->DriverUnload = (PDRIVER_UNLOAD)ioctl::DriverUnload;
	DriverObject->MajorFunction[IRP_MJ_CREATE] = ioctl::DispatchCreate;         
	DriverObject->MajorFunction[IRP_MJ_CLOSE] = ioctl::DispatchClose;           
	DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = ioctl::DispatchIoctl; 
	KPrint("hello world");
	return STATUS_SUCCESS;
}