#include "common.h"

// ----------------------------------------------------------------------------------------
// �ص�����
// ----------------------------------------------------------------------------------------

// ��ʵ������װʱ����
NTSTATUS InstanceSetup(_In_ PCFLT_RELATED_OBJECTS FltObjects, _In_ FLT_INSTANCE_SETUP_FLAGS Flags, _In_ DEVICE_TYPE VolumeDeviceType, _In_ FLT_FILESYSTEM_TYPE VolumeFilesystemType)
{
	DbgPrint("[LyShark] ��װ MiniFilter \n");
	return STATUS_SUCCESS;
}

// ��ʵ��������ʱ����
NTSTATUS InstanceQueryTeardown(_In_ PCFLT_RELATED_OBJECTS FltObjects, _In_ FLT_INSTANCE_QUERY_TEARDOWN_FLAGS Flags)
{
	DbgPrint("[LyShark] ���� MiniFilter \n");
	return STATUS_SUCCESS;
}

// ʵ�������ʱ����
VOID InstanceTeardownStart(_In_ PCFLT_RELATED_OBJECTS FltObjects, _In_ FLT_INSTANCE_TEARDOWN_FLAGS Flags)
{
	DbgPrint("[LyShark] ��� MiniFilter \n");
}

// ʵ��������ʱ����
VOID InstanceTeardownComplete(_In_ PCFLT_RELATED_OBJECTS FltObjects, _In_ FLT_INSTANCE_TEARDOWN_FLAGS Flags)
{
	DbgPrint("[LyShark] ������ MiniFilter \n");
}

// �����ر�ʱж�ؼ��
NTSTATUS Unload(_In_ FLT_FILTER_UNLOAD_FLAGS Flags)
{
	DbgPrint("[LyShark] ж�� MiniFilter \n");
	FltUnregisterFilter(gFilterHandle);
	return STATUS_SUCCESS;
}

// �ص�������
CONST FLT_OPERATION_REGISTRATION Callbacks[] =
{
	// ����ʱ���� PreOperation(֮ǰ�ص�����) / PostOperation(֮��ص�����)
	{ IRP_MJ_CREATE, 0, PreOperation, PostOperation },
	// ��ȡʱ����
	{ IRP_MJ_READ, 0, PreOperation, PostOperation },
	// д�봥��
	{ IRP_MJ_WRITE, 0, PreOperation, PostOperation },
	{ IRP_MJ_QUERY_INFORMATION, 0, PreOperation, PostOperation },
	// ����ʱ����
	{ IRP_MJ_SET_INFORMATION, 0, PreOperation, PostOperation },
	{ IRP_MJ_CREATE_NAMED_PIPE, 0, PreOperation, PostOperation },
	{ IRP_MJ_CREATE_MAILSLOT, 0, PreOperation, PostOperation },


	{ IRP_MJ_QUERY_EA, 0, PreOperation, PostOperation },
	{ IRP_MJ_SET_EA, 0, PreOperation, PostOperation },
	{ IRP_MJ_FLUSH_BUFFERS, 0, PreOperation, PostOperation },

	{ IRP_MJ_QUERY_VOLUME_INFORMATION, 0, PreOperation, PostOperation },
	{ IRP_MJ_SET_VOLUME_INFORMATION, 0, PreOperation, PostOperation },
	{ IRP_MJ_DIRECTORY_CONTROL, 0, PreOperation, PostOperation },

	{ IRP_MJ_FILE_SYSTEM_CONTROL, 0, PreOperation, PostOperation },
	{ IRP_MJ_DEVICE_CONTROL, 0, PreOperation, PostOperation },
	{ IRP_MJ_INTERNAL_DEVICE_CONTROL, 0, PreOperation, PostOperation },
	{ IRP_MJ_SHUTDOWN, 0, PreOperation, PostOperation },
	{ IRP_MJ_LOCK_CONTROL, 0, PreOperation, PostOperation },
	{ IRP_MJ_CLEANUP, 0, PreOperation, PostOperation },

	{ IRP_MJ_QUERY_SECURITY, 0, PreOperation, PostOperation },
	{ IRP_MJ_SET_SECURITY, 0, PreOperation, PostOperation },
	{ IRP_MJ_QUERY_QUOTA, 0, PreOperation, PostOperation },
	{ IRP_MJ_SET_QUOTA, 0, PreOperation, PostOperation },

	{ IRP_MJ_PNP, 0, PreOperation, PostOperation },
	{ IRP_MJ_ACQUIRE_FOR_SECTION_SYNCHRONIZATION, 0, PreOperation, PostOperation },
	{ IRP_MJ_RELEASE_FOR_SECTION_SYNCHRONIZATION, 0, PreOperation, PostOperation },


	{ IRP_MJ_CLOSE, 0, PreOperation, PostOperation },
	
	// ������־
	{ IRP_MJ_OPERATION_END }
};

CONST IRP_DESC g_DESCS[] = {
	{ IRP_MJ_CREATE, L"Create",NULL },
	// ��ȡʱ����
	{ IRP_MJ_READ,  L"Read",NULL },
	// д�봥��
	{ IRP_MJ_WRITE,  L"Write",NULL },
	{ IRP_MJ_QUERY_INFORMATION,  L"Query Information",NULL },
	// ����ʱ����
	{ IRP_MJ_SET_INFORMATION,  L"Set Information",NULL },
	{ IRP_MJ_CREATE_NAMED_PIPE, L"Create NamedPipe",NULL },
	{ IRP_MJ_CREATE_MAILSLOT, L"Create Mailslot",NULL },


	{ IRP_MJ_QUERY_EA,  L"Query Ext Attributes",NULL },
	{ IRP_MJ_SET_EA, L"Set Ext Attributes",NULL },
	{ IRP_MJ_FLUSH_BUFFERS, L"Flush Buffers",NULL },

	{ IRP_MJ_QUERY_VOLUME_INFORMATION,  L"QueryVolumeInformation",NULL },
	{ IRP_MJ_SET_VOLUME_INFORMATION, L"SetVolumeInformation" ,NULL },
	{ IRP_MJ_DIRECTORY_CONTROL,  L"Directory Controls" ,NULL },

	{ IRP_MJ_FILE_SYSTEM_CONTROL,  L"FileSystem" ,NULL },
	{ IRP_MJ_DEVICE_CONTROL, L"Device control" ,NULL },
	{ IRP_MJ_INTERNAL_DEVICE_CONTROL, L"Internal device control",NULL },
	{ IRP_MJ_SHUTDOWN,  L"Shutdown",IRP_ShutdownNotify },
	{ IRP_MJ_LOCK_CONTROL, L"FileObject lcok" ,NULL },
	{ IRP_MJ_CLEANUP, L"FileObject handle ref 0" ,NULL },

	{ IRP_MJ_QUERY_SECURITY,  L"GetSecurityInfo" ,NULL },
	{ IRP_MJ_SET_SECURITY, L"SetSecurityInfo" ,NULL },
	{ IRP_MJ_QUERY_QUOTA,  L"Query disk quota" ,NULL },
	{ IRP_MJ_SET_QUOTA,  L"Set disk quota" ,NULL },

	{ IRP_MJ_PNP,  L"PNP",NULL },
	{ IRP_MJ_ACQUIRE_FOR_SECTION_SYNCHRONIZATION,  L"Acquire SYNC" ,NULL },
	{ IRP_MJ_RELEASE_FOR_SECTION_SYNCHRONIZATION, L"Release SYNC" ,NULL },


	{ IRP_MJ_CLOSE,  L"Close" ,NULL },
	
	// ������־
	{ IRP_MJ_OPERATION_END }
};

// �����������ݽṹ
CONST FLT_REGISTRATION FilterRegistration =
{
	sizeof(FLT_REGISTRATION),           //  �ṹ��С(Ĭ��)
	FLT_REGISTRATION_VERSION,           //  �ṹ�汾(Ĭ��)
	0,                                  //  ��������־
	NULL,                               //  ������
	Callbacks,                          //  ע��ص�������
	Unload,                             //  ����ж�غ���
	InstanceSetup,                      //  ʵ����װ�ص�����
	InstanceQueryTeardown,              //  ʵ�����ٻص�����
	InstanceTeardownStart,              //  ʵ�������ʱ����
	InstanceTeardownComplete,           //  ʵ��������ʱ����
	NULL,                               //  GenerateFileName
	NULL,                               //  GenerateDestinationFileName
	NULL                                //  NormalizeNameComponent
};

// ----------------------------------------------------------------------------------------
// ���ܺ���
// ----------------------------------------------------------------------------------------

// Ԥ�����ص�����(��ִ�й��˲���֮ǰ��ִ�д˴�)
FLT_PREOP_CALLBACK_STATUS PreOperation(_Inout_ PFLT_CALLBACK_DATA Data, _In_ PCFLT_RELATED_OBJECTS FltObjects, _Flt_CompletionContext_Outptr_ PVOID *CompletionContext)
{
	NTSTATUS status;

	// ��ȡ�ļ�·��
	UCHAR MajorFunction = Data->Iopb->MajorFunction;
	PFLT_FILE_NAME_INFORMATION lpNameInfo = NULL;

	// �õ��ļ��������Ϣ
	status = FltGetFileNameInformation(Data, FLT_FILE_NAME_NORMALIZED | FLT_FILE_NAME_QUERY_DEFAULT, &lpNameInfo);
	if (NT_SUCCESS(status))
	{
		status = FltParseFileNameInformation(lpNameInfo);
		if (NT_SUCCESS(status))
		{
			/*
			retrieve current process id
			white list will only allow the specified process pid or image name to access file (IRP  read, write)
			*/
			
			// IRQL <= DISPATCH_LEVEL
			PEPROCESS process = FltGetRequestorProcess(Data);
			CHAR* name = (char*)PsGetProcessImageFileName(process);
			DbgPrint("[currnet process] %s\n",name);

			for (int i = 0; i < ARRAYSIZE(BlackList_ProcessImageName); i++)
			{
				if(strcmp(BlackList_ProcessImageName[i],name) == 0){
					DbgPrint("[block process] %s\n", name);
					Data->IoStatus.Status = STATUS_ACCESS_DENIED;
					Data->IoStatus.Information = 0;
					return FLT_PREOP_COMPLETE;
				}
			}


#pragma region block fs  file exts

			DbgPrint("[ext] %wZ\n", &lpNameInfo->Extension);

			UNICODE_STRING fileExt = {0};

			for (ULONG i = 0; i < ARRAYSIZE(BlackList_FilleExt); i++)
			{
				RtlInitUnicodeString(&fileExt,BlackList_FilleExt[i]);
				if(0 == RtlCompareUnicodeString((&lpNameInfo->Extension),&fileExt,TRUE)){
					DbgPrint("[block file] %wZ\n", &lpNameInfo->Name);
					Data->IoStatus.Status = STATUS_ACCESS_DENIED;
					Data->IoStatus.Information = 0;
					return FLT_PREOP_COMPLETE;
				}
			}

#pragma endregion
			

#pragma region print

			for (ULONG i = 0; i < ARRAYSIZE(g_DESCS); i++)
			{
				if(MajorFunction == g_DESCS[i].IRP){
					DbgPrint("[%ws] %wZ\n",g_DESCS[i].DESC,&lpNameInfo->Name);
					// �ܾ�����
					// STATUS_INSUFFICIENT_RESOURCES                 ��ʾ������Ч����Դ
					// STATUS_ACCESS_DISABLED_NO_SAFER_UI_BY_POLICY  ��Ĭ�ܾ�
					// STATUS_ACCESS_DENIED                          ��ʾ���ʾܾ�
					// return STATUS_ACCESS_DENIED;
					// return FLT_PREOP_COMPLETE;
					if(NULL != g_DESCS[i].Callback){
						g_DESCS[i].Callback();
					}
					break;
				}
			}

#pragma endregion
		}
	}
	///*
	//FltReleaseFileNameInformattion   releases a file name information structure
	//decrements the refereence count on a file name information
	//*/
	//FltReleaseFileNameInformation(lpNameInfo);

	return FLT_PREOP_SUCCESS_WITH_CALLBACK;
}

// ������ص����� (��ִ�й���֮�����д˴�)
FLT_POSTOP_CALLBACK_STATUS PostOperation(_Inout_ PFLT_CALLBACK_DATA Data, _In_ PCFLT_RELATED_OBJECTS FltObjects, _In_opt_ PVOID CompletionContext, _In_ FLT_POST_OPERATION_FLAGS Flags)
{
	return FLT_POSTOP_FINISHED_PROCESSING;
}

// ----------------------------------------------------------------------------------------
// ��ں���
// ----------------------------------------------------------------------------------------
NTSTATUS DriverEntry(_In_ PDRIVER_OBJECT DriverObject, _In_ PUNICODE_STRING RegistryPath)
{
	NTSTATUS status;

	DbgPrint("Hello LyShark.com \n");

	// FltRegisterFilter ����˹�����ע�������
	// ����1����������������
	// ����2��΢�������������ṹ
	// ����3������ע��ɹ���΢�����������
	status = FltRegisterFilter(DriverObject, &FilterRegistration, &gFilterHandle);
	if (NT_SUCCESS(status))
	{
		// ��������
		status = FltStartFiltering(gFilterHandle);
		DbgPrint("[������] �������.. \n");

		if (!NT_SUCCESS(status))
		{
			// �������ʧ��,s
			FltUnregisterFilter(gFilterHandle);
			DbgPrint("[������] ȡ��ע��.. \n");
		}
	}else
	{
		DbgPrint("FltRegisterFilter failed 0x%x \n",status);
	}

	return status;
}


VOID IRP_ShutdownNotify(){
	DbgPrint("IRP_MJ_SHUTDOWN\n");
	/*
	warning!!!
	remember remove it before building your own driver.
	*/
	DbgBreakPoint();
}